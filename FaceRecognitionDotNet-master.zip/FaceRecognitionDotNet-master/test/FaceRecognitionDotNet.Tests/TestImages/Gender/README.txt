https://en.wikipedia.org/wiki/Whitney_Houston#/media/File:Whitney_Houston_Welcome_Home_Heroes_1_cropped.jpg
https://en.wikipedia.org/wiki/Mao_Asada#/media/File:Mao_Asada_Podium_2014_World_Championships.jpg
https://en.wikipedia.org/wiki/Diana,_Princess_of_Wales#/media/File:Diana,_Princess_of_Wales_1997_(2).jpg
https://en.wikipedia.org/wiki/Shinz%C5%8D_Abe#/media/File:Shinz%C5%8D_Abe_Official_(cropped_2).jpg
https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/President_Barack_Obama.jpg/220px-President_Barack_Obama.jpg
