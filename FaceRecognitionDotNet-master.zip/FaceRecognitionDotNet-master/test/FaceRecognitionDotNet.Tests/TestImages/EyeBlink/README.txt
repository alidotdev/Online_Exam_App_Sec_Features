* https://upload.wikimedia.org/wikipedia/commons/6/60/Ad%C3%A8le_Haenel_Cannes_2016.jpg
  * rename file to Adele_Haenel_Cannes_2016.jpg for test
  * Adele_Haenel_Cannes_2016_mirror.jpg is mirrored Adele_Haenel_Cannes_2016.jpg for test