https://en.wikipedia.org/wiki/Mao_Asada#/media/File:Mao_Asada_Podium_2014_World_Championships.jpg
https://en.wikipedia.org/wiki/Diana,_Princess_of_Wales#/media/File:Diana,_Princess_of_Wales_1997_(2).jpg
https://en.wikipedia.org/wiki/Macaulay_Culkin#/media/File:Macaulay_Culkin_1991_B.jpg
https://en.wikipedia.org/wiki/Nelson_Mandela#/media/File:Nelson_Mandela-2008.jpg
