# FaceRecognitionDotNet API Document

FaceRecognitionDotNet provides simplest facial recognition api for .NET on Windows, MacOS and Linux.