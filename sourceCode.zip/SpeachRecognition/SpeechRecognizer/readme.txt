﻿thanks to Lukasz Kwiecinski, Istrib for his article and source code http://www.codeproject.com/KB/audio-video/Mp3SoundCapture.aspx
thanks to Alexander Yakhnev for the article http://habrahabr.ru/blogs/google/117234/  and source code http://startup-news.ru/data/habrGoogleSpeech.zip
This project is based on these guys works.

Using of speech-recognition API seems to be an undocummented feature of google voice search. That's working though, at least today,  October 28 2011.
