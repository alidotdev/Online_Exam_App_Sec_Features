﻿using System.Windows;

namespace FaceDetectionAndRecognition
{
    /// <summary>
    /// Interaction logic for WFAbout.xaml
    /// </summary>
    public partial class WFAbout : Window
    {
        public WFAbout()
        {
            InitializeComponent();
        }
    }
}
