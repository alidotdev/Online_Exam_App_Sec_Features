#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <conio.h>
#include <windows.h>
#include <cmath>

using namespace std;

#define KEY_UP 72
#define KEY_DOWN 80
#define KEY_LEFT 75
#define KEY_RIGHT 77

const short int ROWS = 4;
const short int COLUMNS = 4;
const short int WIN_TILE = 2048;

void initialize(short int arr[][COLUMNS]);
void display(short int arr[][COLUMNS], int score, int totalMoves);
void dispalyBox(short int arr[][COLUMNS]);
char status(short int arr[][COLUMNS]);
void generateNT(short int arr[][COLUMNS]);
void moveUp(short int arr[][COLUMNS], bool &change, int &score, int &totalMoves);
void moveDown(short int arr[][COLUMNS], bool &change, int &score, int &totalMoves);
void moveLeft(short int arr[][COLUMNS], bool &change, int &score, int &totalMoves);
void moveRight(short int arr[][COLUMNS], bool &change, int &score, int &totalMoves);
void printWithColor(short int num);

int main()
{
    short int arr[ROWS][COLUMNS];
    char repeat;
    do
    {
        initialize(arr);

        generateNT(arr);
        generateNT(arr);

        char move;
        char gameStauts;
        bool change = 0;
        int score = 0;
        int totalMoves = 0;
        display(arr, score, totalMoves);

        do
        {

        inputMove:
            cout << "Enter the move: ";
            move = getch();

            switch (move)
            {
            case 'w':
            case 'W':
            case KEY_UP:
                moveUp(arr, change, score, totalMoves);
                break;
            case 'a':
            case 'A':
            case KEY_LEFT:
                moveLeft(arr, change, score, totalMoves);
                break;
            case 's':
            case 'S':
            case KEY_DOWN:
                moveDown(arr, change, score, totalMoves);
                break;
            case 'd':
            case 'D':
            case KEY_RIGHT:
                moveRight(arr, change, score, totalMoves);
                break;

            default:
                cout << "Invalid Choice. Try Again\n";
                goto inputMove;
                break;
            }

            if (change)
            {
                generateNT(arr);
                change = 0;
                totalMoves++;
            }

            display(arr, score, totalMoves);

            gameStauts = status(arr);

        } while (gameStauts == 'c');

        if (gameStauts == 'w')
            cout << "\nCongratulations! You won the game.";
        else if (gameStauts == 'l')
            cout << "\nYou lose the game. Better luck next time.\n";

        cout << "Press any key to Continue!...";
        getch();

        cout << "\nDo you want to Play again: ";
        cout << "Press y for YES and n for NO\n";
        cin >> repeat;

        while (repeat != 'y' && repeat != 'Y' && repeat != 'n' && repeat != 'N')
        {
            cout << "Invalid choice. Try again!";
            cout << "\nDo you want to Play again: ";
            cout << "Press y for YES and n for NO\n";
            cin >> repeat;
        }
    } while (repeat == 'y' || repeat == 'Y');

    return 0;
}

void initialize(short int arr[][COLUMNS])
{
    for (short int r = 0; r < ROWS; r++)
        for (short int c = 0; c < COLUMNS; c++)
            arr[r][c] = 0;
}

void display(short int arr[][COLUMNS], int score, int totalMoves)
{
    system("cls");

    cout << " 222222222222222         000000000            444444444       888888888     \n";
    cout << "2:::::::::::::::22     00:::::::::00         4::::::::4     88:::::::::88   \n";
    cout << "2::::::222222:::::2  00:::::::::::::00      4:::::::::4   88:::::::::::::88 \n";
    cout << "2222222     2:::::2 0:::::::000:::::::0    4::::44::::4  8::::::88888::::::8\n";
    cout << "            2:::::2 0::::::0   0::::::0   4::::4 4::::4  8:::::8     8:::::8\n";
    cout << "            2:::::2 0:::::0     0:::::0  4::::4  4::::4  8:::::8     8:::::8\n";
    cout << "         2222::::2  0:::::0     0:::::0 4::::4   4::::4   8:::::88888:::::8 \n";
    cout << "    22222::::::22   0:::::0 000 0:::::04::::444444::::444  8:::::::::::::8  \n";
    cout << "  22::::::::222     0:::::0 000 0:::::04::::::::::::::::4 8:::::88888:::::8 \n";
    cout << " 2:::::22222        0:::::0     0:::::04444444444:::::4448:::::8     8:::::8\n";
    cout << "2:::::2             0:::::0     0:::::0          4::::4  8:::::8     8:::::8\n";
    cout << "2:::::2             0::::::0   0::::::0          4::::4  8:::::8     8:::::8\n";
    cout << "2:::::2       2222220:::::::000:::::::0          4::::4  8::::::88888::::::8\n";
    cout << "2::::::2222222:::::2 00:::::::::::::00         44::::::44 88:::::::::::::88 \n";
    cout << "2::::::::::::::::::2   00:::::::::00           4::::::::4   88:::::::::88   \n";
    cout << "22222222222222222222     000000000             4444444444     888888888     \n\n\n\n";

    cout << setw(13) << "Moves: " << setw(4) << totalMoves << setw(20) << "Your Score: " << setw(5) << score << endl;

    dispalyBox(arr);
}

void dispalyBox(short int arr[][COLUMNS])
{
    cout << "\t_";
    for (short int i = 0; i < ROWS; i++)
        cout << "_______";
    cout << endl;

    for (short int r = 0; r < ROWS; r++)
    {
        cout << "\t|";
        for (short int i = 0; i < ROWS; i++)
            cout << "      |";
        cout << endl;

        cout << "\t|";
        for (short int c = 0; c < COLUMNS; c++)
        {
            cout << setw(5);

            if (arr[r][c] != 0)
            {
                printWithColor(arr[r][c]);
                // cout << arr[r][c] << " ";
            }
            else
                cout << ' ' << ' ';

            cout << "|";
        }

        cout << "\n\t|";
        for (short int i = 0; i < ROWS; i++)
            cout << "______|";
        cout << endl;
    }
}

//this function returns 'w' when palyer wins else returns 'l' when palyer loses else returns 'c';
char status(short int arr[][COLUMNS])
{
    //if WIN_TILE tile is found Player wins
    for (short int r = 0; r < ROWS; r++)
        for (short int c = 0; c < COLUMNS; c++)
            if (arr[r][c] == WIN_TILE)
                return 'w';

    for (short int r = 0; r < ROWS; r++)
        for (short int c = 0; c < COLUMNS; c++)
            if (arr[r][c] == 0)
                return 'c';

    for (short int r = 0; r < ROWS - 1; r++)
        for (short int c = 0; c < COLUMNS - 1; c++)
            if (arr[r][c] == arr[r + 1][c] || arr[r][c] == arr[r][c + 1])
                return 'c';

    return 'l';
}

void generateNT(short int arr[][COLUMNS])
{
    srand(time(0));
    short int num = rand() % 7;
    for (short i = 0; i < 50; i++)
    {
        short int r = rand() % 4;
        short int c = rand() % 4;
        if (!arr[r][c])
        {
            arr[r][c] = (num) ? 2 : 4;
            break;
        }
    }
}

void moveUp(short int arr[][COLUMNS], bool &change, int &score, int &totalMoves)
{
    for (short int c = 0; c < COLUMNS; c++)
    {
        short int r = 0;
        for (short int i = 1; i < ROWS; i++)
        {
            if (arr[i][c] != 0 && i != r)
            {
                if (arr[r][c] == 0)
                {
                    short int temp = arr[i][c];
                    arr[i][c] = 0;
                    arr[r][c] = temp;
                    change = 1;
                }
                else if (arr[r][c] == arr[i][c])
                {
                    short int temp = arr[i][c];
                    arr[i][c] = 0;
                    arr[r][c] += temp;
                    score += arr[r][c];
                    change = 1;
                    r++;
                }
                else if (arr[r][c] != arr[i][c])
                {
                    r++;
                    i--; //do not change the value of i;
                }
            }
        }
    }
}

void moveDown(short int arr[][COLUMNS], bool &change, int &score, int &totalMoves)
{
    for (short int c = 0; c < COLUMNS; c++)
    {
        short int r = ROWS - 1;
        for (short int i = ROWS - 2; i >= 0; i--)
        {
            if (arr[i][c] != 0 && i != r)
            {
                if (arr[r][c] == 0)
                {
                    short int temp = arr[i][c];
                    arr[i][c] = 0;
                    arr[r][c] = temp;
                    change = 1;
                }
                else if (arr[r][c] == arr[i][c])
                {
                    short int temp = arr[i][c];
                    arr[i][c] = 0;
                    arr[r][c] += temp;
                    score += arr[r][c];
                    change = 1;
                    r--;
                }
                else if (arr[r][c] != arr[i][c])
                {
                    r--;
                    i++; //do not change the value of i;
                }
            }
        }
    }
}

void moveLeft(short int arr[][COLUMNS], bool &change, int &score, int &totalMoves)
{
    for (short int r = 0; r < ROWS; r++)
    {
        short int c = 0;
        for (short i = 1; i < COLUMNS; i++)
        {
            if (arr[r][i] != 0 && i != c)
            {
                if (arr[r][c] == 0)
                {
                    short int temp = arr[r][i];
                    arr[r][i] = 0;
                    arr[r][c] = temp;
                    change = 1;
                }
                else if (arr[r][c] == arr[r][i])
                {
                    short int temp = arr[r][i];
                    arr[r][i] = 0;
                    arr[r][c] += temp;
                    score += arr[r][c];
                    change = 1;
                    c++;
                }
                else if (arr[r][c] != arr[r][i])
                {
                    c++;
                    i--; //do not change the value of i;
                }
            }
        }
    }
}

void moveRight(short int arr[][COLUMNS], bool &change, int &score, int &totalMoves)
{
    for (short int r = 0; r < ROWS; r++)
    {
        short int c = COLUMNS - 1;
        for (short int i = COLUMNS - 2; i >= 0; i--)
        {
            if (arr[r][i] != 0 && i != c)
            {
                if (arr[r][c] == 0)
                {
                    short int temp = arr[r][i];
                    arr[r][i] = 0;
                    arr[r][c] = temp;
                    change = 1;
                }
                else if (arr[r][c] == arr[r][i])
                {
                    short int temp = arr[r][i];
                    arr[r][i] = 0;
                    arr[r][c] += temp;
                    score += arr[r][c];
                    change = 1;
                    c--;
                }
                else if (arr[r][c] != arr[r][i])
                {
                    c--;
                    i++; //do not change the value of i;
                }
            }
        }
    }
}

void printWithColor(short int num)
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

    short int a = log2(num);

    switch ( a )
    {
        case 1:
            SetConsoleTextAttribute(hConsole, 1);
            break;
        case 2:
            SetConsoleTextAttribute(hConsole, 2);
            break;
        case 3:
            SetConsoleTextAttribute(hConsole, 3);
            break;
        case 4:
            SetConsoleTextAttribute(hConsole, 12);
            break;
        case 5:
            SetConsoleTextAttribute(hConsole, 13);
            break;
        case 6:
            SetConsoleTextAttribute(hConsole, 15);
            break;
        case 7:
            SetConsoleTextAttribute(hConsole, 11);
            break;
        case 8:
            SetConsoleTextAttribute(hConsole, 12);
            break;
        case 9:
            SetConsoleTextAttribute(hConsole, 9);
            break;
        case 10:
            SetConsoleTextAttribute(hConsole, 6);
            break;
        case 11:
        case 12:
            SetConsoleTextAttribute(hConsole, 14);
            break;
    }

    cout << num << " ";
    SetConsoleTextAttribute(hConsole, 7);
}