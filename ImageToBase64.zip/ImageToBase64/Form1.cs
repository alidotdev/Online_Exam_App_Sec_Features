﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ImageToBase64
{
    public partial class Form1 : Form
    {
        Bitmap image;
        string base64Text;
        public Form1()
        {
            InitializeComponent();
        }

        public System.Drawing.Image Base64ToImage()
        {
            byte[] imageBytes = Convert.FromBase64String(base64Text);
            MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);
            ms.Write(imageBytes, 0, imageBytes.Length);
            System.Drawing.Image image = System.Drawing.Image.FromStream(ms, true);
            return image;
        }

        //////////////////////////////////////////////////////////////////FILE HANDLING///////////////////////////////////////////////////////////////////
        private void button2_Click(object sender, EventArgs e)
        {
            string path = @"D:\ImageToBase64\data.txt";
            using (StreamWriter stream = File.CreateText(path))
            {
                stream.Write(richTextBox1.Text);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image Files(*.BMP;*.JPG;*.PNG)|*.BMP;*.JPG;*.PNG" + "|All Files(*.*)|*.*";
            dialog.CheckFileExists = true;
            dialog.Multiselect = false;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                image = new Bitmap(dialog.FileName);
                pictureBox1.Image = (Image)image;

                byte[] imageArray = System.IO.File.ReadAllBytes(dialog.FileName);
                base64Text = Convert.ToBase64String(imageArray);
                richTextBox1.Text = base64Text;

            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Decrypt_Click(object sender, EventArgs e)
        {
            /*            String dirPath = "D:\ImageToBase64";
                        String imgName = "my_mage_name.bmp";
                        byte[] imgByteArray = Convert.FromBase64String("your_base64_string");
                        File.WriteAllBytes(dirPath + imgName, imgByteArray);*/


            //BitmapImage mapImage = new BitmapImage();
            //string base64String = File.ReadAllText(@"D:\ImageToBase64\data.txt");
            //byte[] imgBytes = Convert.FromBase64String(base64String);

            //MemoryStream ms = new MemoryStream(imgBytes);
            //BitmapImage
            //            image.StreamSource = ms;
            //image.EndInit();

            ////Image object
            //image.Source = bitmapImage;


            try
            {
                base64Text = richTextBox1.Text;
                pictureBox1.Image = Base64ToImage();

            }
            catch (ArgumentException)
            {
                MessageBox.Show(null, "Null input", "Error");
            }


        }

        private void PngSave_Click(object sender, EventArgs e)
        {

            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Image Files(*.BMP;*.JPG;*.PNG)|*.BMP;*.JPG;*.PNG" + "|All Files(*.*)|*.*";
            save.InitialDirectory = Directory.GetCurrentDirectory();
            save.ShowDialog();
            if (String.IsNullOrEmpty(save.FileName))
            {
                MessageBox.Show(null, "Invalid name!", "ERROR");
            }
            else
            {
                string path = save.FileName;
                System.Drawing.Image img = Base64ToImage();
                img.Save(save.FileName);
                img.Save(path);

            }


        }
    }
}

